---
title: "Membangun Website Portfolio dengan Next.js dan Tailwind CSS"
date: "2023-12-15"
excerpt: "Panduan langkah demi langkah untuk membuat website portfolio yang menarik menggunakan Next.js dan Tailwind CSS."
image: "/placeholder.svg?height=400&width=800"
tags: ["web development", "next.js", "tailwind css", "tutorial"]
---

# Membangun Website Portfolio dengan Next.js dan Tailwind CSS

Next.js dan Tailwind CSS adalah kombinasi yang sangat kuat untuk membangun website modern. Dalam artikel ini, saya akan berbagi pengalaman dan langkah-langkah dalam membangun website portfolio pribadi.

## Mengapa Next.js?

Next.js menawarkan banyak fitur yang membuatnya menjadi pilihan tepat untuk website portfolio:

- **Server-side Rendering (SSR)** - Meningkatkan SEO dan performa
- **Static Site Generation (SSG)** - Kecepatan loading yang luar biasa
- **Routing berbasis file** - Struktur proyek yang intuitif
- **API Routes** - Backend dan frontend dalam satu proyek

## Mengapa Tailwind CSS?

Tailwind CSS adalah framework CSS utility-first yang memungkinkan:

- Pengembangan UI yang cepat
- Kustomisasi yang fleksibel
- Bundle size yang optimal dengan purging
- Konsistensi desain

## Langkah 1: Setup Proyek

Pertama, buat proyek Next.js baru dengan Tailwind CSS:

```bash
npx create-next-app@latest my-portfolio --typescript --tailwind
cd my-portfolio

